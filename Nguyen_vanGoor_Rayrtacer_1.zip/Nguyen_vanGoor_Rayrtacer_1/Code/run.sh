make
./ray scene01-phong.yaml
./ray scene01-normal.yaml
./ray scene01-zbuffer.yaml
./ray scene02.yaml
